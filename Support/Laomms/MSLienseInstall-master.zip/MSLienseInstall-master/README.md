*支持安装、卸载证书  
*支持批量导入、批量导出、批量卸载证书。  
*支持Windows10系统版本转换，支持Office2010-2019专业增强版零售批量互转。  

![image](https://github.com/laomms/MSLienseInstall/blob/master/LicenseInstall.gif)   

Support:

#Windows6.0:  
Windows Vista  
Windows Server 2008  
Windows Server 2008 Foundation  
Windows Server 2008 HPC  
Windows Small Business Server 2008  
Windows Essential Business Server 2008  
Windows Storage Server 2008  

#Windows6.1:  
Windows 7 Enterprise(N)  
Windows 7 Home Basic(N)  
Windows 7 Home Premium(N)  
Windows 7 Professional(N)  
Windows 7 Starter(N)  
Windows 7 Ultimate(N)  
Windows Home Server 2011  
Windows Hyper-V Server 2008R2  
Windows Multipoint Server 2010  
Windows Multipoint Server 2011  
Windows Server 2008R2  
Windows Server 2008R2 Foundation  
Windows Server 2008R2 HPC  
Windows Storage Server 2008R2  
Windows Thin PC  

#Windows6.2:  
Windows 8 Enterprise(N)  
Windows 8 Professional(N)  
Windows 8 Core(N)  
Windows 8 CoreCountrySpecific  
Windows 8 CoreSingleLanguage  
Windows Embedded 8 Industry Pro  
Windows Embedded Compact 2013  
Windows Hyper-V Server 2012  
Windows Multipoint Server 2012  
Windows Server 2012  
Windows Server 2012 Essentials  
Windows Server 2012 HPC  
Windows Server 2012 Storage Server and Foundation  

#Windows6.3:  
Windows 8.1 Enterprise (N)  
Windows 8.1 Core(N)  
Windows 8.1 Professional(N)  
Windows 8.1 ProfessionalWMC  
Windows 8.1 Single Language  
Windows 8.1 CoreCountrySpecific  
Windows Embedded 8.1 Industry Enterprise  
Windows Embedded 8.1 Industry Pro  
Windows Embedded Compact 2013  
Windows Server 2012R2  
Windows Hyper-V Server 2012R2  
Windows Server 2012R2 Essentials  
Windows Server 2012R2 HPC  
Windows Server 2012R2 Storage and Foundation  

#Windows10:  
Widnows 10 Pro(N)  
Widnows 10 Core(N)  
Widnows 10 Enterprise(N/NEval)  
Widnows 10 EnterpriseG(N)  
Widnows 10 Education(N)  
Widnows 10 ProfessionalEducation(N)  
Widnows 10 LTSB 2016(N)  
Widnows 10 LTSC 2019(N)  
Widnows 10 CoreSingleLanguage  
Widnows 10 CoreCountrySpecific  
Widnows 10 ProfessionalSingleLanguage  
Widnows 10 Pro for Workstation(N)  
Widnows 10 PPIPro  
Widnows 10 Cloud(N)  
Widnows 10 Server Remote Desktop  
Widnows Server 2016(All)  
Widnows Server 2019(All)  

#Office
Office2010-2019
